
import React from 'react';
import { Edit2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

const AdminTable = ({ columns, data, onEdit, onDelete, isLoading, emptyMessage = "No data available" }) => {
  if (isLoading) {
    return (
      <div className="flex justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-[#E0A995]" />
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center p-12 text-[#A8B3AF] border border-dashed border-[#E0A995]/20 rounded-lg">
        {emptyMessage}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-[#E0A995]/20">
      <table className="w-full text-left text-sm text-[#EBE8E3]">
        <thead className="bg-[#13251E] text-[#E0A995] uppercase font-medium">
          <tr>
            {columns.map((col, idx) => (
              <th key={idx} className="px-6 py-4">{col.label}</th>
            ))}
            <th className="px-6 py-4 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#E0A995]/10 bg-[#0F1C15]">
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className="hover:bg-[#E0A995]/5 transition-colors">
              {columns.map((col, colIndex) => (
                <td key={colIndex} className="px-6 py-4">
                  {col.render ? col.render(row) : row[col.key]}
                </td>
              ))}
              <td className="px-6 py-4 text-right flex justify-end gap-2">
                {onEdit && (
                  <Button variant="ghost" size="icon" onClick={() => onEdit(row)} className="text-[#A8B3AF] hover:text-[#E0A995]">
                    <Edit2 className="w-4 h-4" />
                  </Button>
                )}
                {onDelete && (
                  <Button variant="ghost" size="icon" onClick={() => onDelete(row)} className="text-[#A8B3AF] hover:text-red-500">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminTable;
