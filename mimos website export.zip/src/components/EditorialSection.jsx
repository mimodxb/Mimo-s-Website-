
import React from 'react';
import { motion } from 'framer-motion';

const EditorialSection = () => {
  return (
    <section className="relative py-24 px-8 bg-[#0A1612] overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0A1612] via-[#0F221C] to-[#0A1612] opacity-50" />
      
      <div className="relative max-w-4xl mx-auto z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }} 
          whileInView={{ opacity: 1, y: 0 }} 
          viewport={{ once: true }} 
          transition={{ duration: 0.8 }} 
          className="text-center space-y-12 glass-panel p-12 rounded-2xl"
        >
          {/* Copper Divider */}
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#E0A995]" />
            <div className="w-2 h-2 rounded-full bg-[#E0A995]" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#E0A995]" />
          </div>

          <h2 className="text-4xl lg:text-5xl font-serif font-bold text-[#EBE8E3] leading-tight">
            Two Worlds. <span className="text-[#E0A995]">One Story.</span>
          </h2>

          <div className="space-y-6 text-lg text-[#A8B3AF] leading-relaxed max-w-3xl mx-auto font-light">
            <p>
              From captivating audiences on screen to building innovative creative ventures, Movsum Mirzazada embodies the convergence of artistic excellence and entrepreneurial vision.
            </p>
            <p>
              His journey spans award-winning performances that have touched hearts worldwide, 
              to founding Mimo's Collective—a platform that empowers creators and redefines storytelling 
              in the digital age.
            </p>
            <p className="text-[#E0A995]/80 font-serif italic text-xl">
              "Art is not just what we create—it's how we inspire others to create."
            </p>
          </div>

          {/* Bottom Divider */}
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#E0A995]" />
            <div className="w-2 h-2 rounded-full bg-[#E0A995]" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#E0A995]" />
          </div>
        </motion.div>
      </div>
    </section>
  );
};
export default EditorialSection;
