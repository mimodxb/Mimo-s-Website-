
import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import UnreadBadge from './UnreadBadge';

const ConversationList = ({ conversations, selectedId, onSelect, loading }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = conversations.filter(c => 
    c.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.subject?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="p-4 text-[#A8B3AF]">Loading conversations...</div>;

  return (
    <div className="h-full flex flex-col bg-[#0F1C15] border-r border-[#E0A995]/10">
      <div className="p-4 border-b border-[#E0A995]/10">
        <h2 className="text-xl font-bold text-[#E0A995] mb-4">Messages</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A8B3AF]" />
          <Input 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search clients or cases..." 
            className="pl-9 bg-[#13251E] border-[#333] text-sm"
          />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-[#A8B3AF] text-sm">No conversations found.</div>
        ) : (
          filtered.map(conv => (
            <div 
              key={conv.id}
              onClick={() => onSelect(conv)}
              className={`p-4 border-b border-[#E0A995]/5 cursor-pointer hover:bg-[#13251E] transition-colors ${selectedId === conv.id ? 'bg-[#13251E] border-l-4 border-l-[#E0A995]' : 'border-l-4 border-l-transparent'}`}
            >
              <div className="flex justify-between items-start mb-1">
                <h3 className="font-bold text-[#EBE8E3] truncate pr-2">{conv.client_name}</h3>
                <span className="text-[10px] text-[#A8B3AF] whitespace-nowrap">
                  {conv.last_message_at ? formatDistanceToNow(new Date(conv.last_message_at), { addSuffix: true }) : 'New'}
                </span>
              </div>
              <p className="text-xs text-[#E0A995] font-medium mb-1 truncate">{conv.subject}</p>
              <div className="flex justify-between items-center">
                <p className="text-xs text-[#A8B3AF] truncate max-w-[80%]">Click to view messages</p>
                <UnreadBadge count={conv.unread_count} />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ConversationList;
