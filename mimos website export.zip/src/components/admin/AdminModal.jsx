
import React, { useState, useEffect } from 'react';
import { X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';

const AdminModal = ({ isOpen, onClose, title, fields, initialData, onSubmit, isLoading }) => {
  const [formData, setFormData] = useState({});

  useEffect(() => {
    if (isOpen) {
      // Initialize form data with initialData or empty strings
      const initial = {};
      fields.forEach(field => {
        initial[field.name] = initialData ? initialData[field.name] : (field.type === 'checkbox' ? false : '');
      });
      setFormData(initial);
    }
  }, [isOpen, initialData, fields]);

  const handleChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-[#0F1C15] border border-[#E0A995]/20 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        >
          <div className="flex items-center justify-between p-6 border-b border-[#E0A995]/10 bg-[#13251E]">
            <h3 className="text-xl font-bold text-[#EBE8E3]">{title}</h3>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5 text-[#A8B3AF]" />
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
            {fields.map((field) => (
              <div key={field.name} className="space-y-2">
                <label className="text-sm text-[#A8B3AF] uppercase font-medium">{field.label}</label>
                
                {field.type === 'textarea' ? (
                  <Textarea
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, e.target.value)}
                    className="bg-[#0A1612] border-[#E0A995]/20 text-white min-h-[100px]"
                    required={field.required}
                  />
                ) : field.type === 'select' ? (
                  <select
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, e.target.value)}
                    className="w-full h-12 px-3 rounded-md bg-[#0A1612] border border-[#E0A995]/20 text-white focus:border-[#E0A995]"
                    required={field.required}
                  >
                    <option value="">Select {field.label}</option>
                    {field.options.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                ) : field.type === 'checkbox' ? (
                  <div className="flex items-center space-x-2 pt-2">
                    <Checkbox
                      id={field.name}
                      checked={formData[field.name] || false}
                      onCheckedChange={(checked) => handleChange(field.name, checked)}
                      className="border-[#E0A995]/20 data-[state=checked]:bg-[#E0A995] data-[state=checked]:text-[#0A1612]"
                    />
                    <label htmlFor={field.name} className="text-white cursor-pointer">Enabled</label>
                  </div>
                ) : (
                  <Input
                    type={field.type || 'text'}
                    value={formData[field.name] || ''}
                    onChange={(e) => handleChange(field.name, e.target.value)}
                    className="bg-[#0A1612] border-[#E0A995]/20 text-white"
                    required={field.required}
                  />
                )}
              </div>
            ))}
            
            <div className="pt-4 flex justify-end gap-3">
              <Button type="button" variant="ghost" onClick={onClose} className="text-[#A8B3AF]">Cancel</Button>
              <Button type="submit" disabled={isLoading} className="bg-[#E0A995] text-[#0A1612] hover:bg-[#D49A89]">
                {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Changes
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default AdminModal;
