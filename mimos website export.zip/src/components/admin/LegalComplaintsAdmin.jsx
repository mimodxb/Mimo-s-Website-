
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import AdminTable from '@/components/admin/AdminTable';
import AdminModal from '@/components/admin/AdminModal';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Download, FileText, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const LegalComplaintsAdmin = () => {
  const [intakes, setIntakes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedIntake, setSelectedIntake] = useState(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const { toast } = useToast();

  const fetchIntakes = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('legal_complaint_intakes')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setIntakes(data);
    setLoading(false);
  };

  useEffect(() => { fetchIntakes(); }, []);

  const handleStatusUpdate = async (id, status, notes) => {
    const { error } = await supabase
      .from('legal_complaint_intakes')
      .update({ status, notes })
      .eq('id', id);
    
    if (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } else {
      toast({ title: "Updated", description: "Case status updated" });
      setDetailsOpen(false);
      fetchIntakes();
    }
  };

  const columns = [
    { key: 'reference_id', label: 'Ref ID' },
    { key: 'full_name', label: 'Client' },
    { key: 'issue_type', label: 'Issue' },
    { key: 'pricing_tier', label: 'Tier', render: r => <span className="uppercase text-xs font-bold px-2 py-1 bg-white/10 rounded">{r.pricing_tier}</span> },
    { key: 'status', label: 'Status', render: r => (
      <span className={`px-2 py-1 rounded text-xs ${
        r.status === 'submitted' ? 'bg-blue-500/20 text-blue-500' :
        r.status === 'in_progress' ? 'bg-yellow-500/20 text-yellow-500' :
        r.status === 'completed' ? 'bg-green-500/20 text-green-500' : 'bg-gray-500/20 text-gray-500'
      }`}>
        {r.status.replace('_', ' ').toUpperCase()}
      </span>
    )},
    { key: 'created_at', label: 'Date', render: r => new Date(r.created_at).toLocaleDateString() },
    { key: 'actions', label: 'View', render: r => (
      <Button variant="outline" size="sm" onClick={() => { setSelectedIntake(r); setDetailsOpen(true); }}>
        Details
      </Button>
    )}
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-[#E0A995]">Legal Intakes ({intakes.length})</h2>
        <Button onClick={() => fetchIntakes()} variant="ghost">Refresh</Button>
      </div>

      <AdminTable columns={columns} data={intakes} isLoading={loading} />

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-4xl bg-[#0F1C15] border-[#E0A995]/20 text-[#EBE8E3] max-h-[90vh] overflow-y-auto">
          {selectedIntake && (
            <div className="space-y-6">
              <div className="flex justify-between border-b border-[#E0A995]/10 pb-4">
                 <div>
                   <h2 className="text-xl font-bold">{selectedIntake.reference_id}</h2>
                   <p className="text-[#A8B3AF]">Submitted by {selectedIntake.full_name} ({selectedIntake.email})</p>
                 </div>
                 <div className="text-right">
                   <p className="text-sm">Tier: <span className="text-[#E0A995] font-bold uppercase">{selectedIntake.pricing_tier}</span></p>
                   <p className="text-sm">Priority: {selectedIntake.response_time}</p>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                   <h3 className="font-bold text-[#E0A995] mb-2">Case Details</h3>
                   <p><strong>Against:</strong> {selectedIntake.complaint_against}</p>
                   <p><strong>Type:</strong> {selectedIntake.issue_type}</p>
                   <p><strong>Start Date:</strong> {selectedIntake.issue_start_date}</p>
                   <p className="mt-2 text-sm bg-[#13251E] p-3 rounded">{selectedIntake.situation_description}</p>
                </div>
                <div>
                   <h3 className="font-bold text-[#E0A995] mb-2">Outcome & Evidence</h3>
                   <p><strong>Desired Outcome:</strong> {selectedIntake.desired_outcome}</p>
                   <div className="mt-2">
                     <strong>Files:</strong>
                     <ul className="list-disc list-inside text-sm">
                       {selectedIntake.file_urls && selectedIntake.file_urls.map((url, i) => (
                         <li key={i}><a href={url} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline">Document {i+1}</a></li>
                       ))}
                       {(!selectedIntake.file_urls || selectedIntake.file_urls.length === 0) && <li>No files</li>}
                     </ul>
                   </div>
                </div>
              </div>

              <div className="bg-[#13251E] p-4 rounded-lg">
                <h3 className="font-bold mb-2">Admin Actions</h3>
                <div className="flex gap-4 items-end">
                   <div className="flex-1">
                     <label className="text-sm mb-1 block">Status</label>
                     <select 
                       className="w-full bg-[#0A1612] border border-[#333] rounded px-2 py-1 text-white"
                       defaultValue={selectedIntake.status}
                       id="statusSelect"
                     >
                       <option value="submitted">Submitted</option>
                       <option value="under_review">Under Review</option>
                       <option value="in_progress">In Progress</option>
                       <option value="completed">Completed</option>
                       <option value="cancelled">Cancelled</option>
                     </select>
                   </div>
                   <div className="flex-[2]">
                     <label className="text-sm mb-1 block">Admin Notes (Client visible if emailed)</label>
                     <input 
                       className="w-full bg-[#0A1612] border border-[#333] rounded px-2 py-1 text-white"
                       defaultValue={selectedIntake.notes || ''}
                       id="notesInput"
                     />
                   </div>
                   <Button onClick={() => {
                     const status = document.getElementById('statusSelect').value;
                     const notes = document.getElementById('notesInput').value;
                     handleStatusUpdate(selectedIntake.id, status, notes);
                   }} className="bg-[#E0A995] text-[#0A1612]">
                     Update Case
                   </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default LegalComplaintsAdmin;
