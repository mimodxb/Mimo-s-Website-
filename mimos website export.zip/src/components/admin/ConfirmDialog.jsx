
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ConfirmDialog = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-[#0F1C15] border border-red-500/30 w-full max-w-sm rounded-xl shadow-2xl p-6"
        >
          <div className="flex flex-col items-center text-center gap-4">
            <div className="w-12 h-12 bg-red-500/10 rounded-full flex items-center justify-center text-red-500">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-[#EBE8E3]">{title}</h3>
            <p className="text-[#A8B3AF] text-sm">{message}</p>
            
            <div className="flex gap-3 w-full mt-4">
              <Button onClick={onClose} variant="ghost" className="flex-1 text-[#A8B3AF]">Cancel</Button>
              <Button onClick={onConfirm} className="flex-1 bg-red-500 hover:bg-red-600 text-white">Confirm</Button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ConfirmDialog;
